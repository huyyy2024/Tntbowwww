package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Trajectory simulation chuẩn Minecraft 1.21.
 *
 * Spawn point của arrow (từ BowItem.onStoppedUsing → ArrowItem.use):
 *   - eyePos: player.getEyePos()
 *   - x/z offset: 0 (tên spawn tại eye X/Z)
 *   - y offset: -0.1 (tên spawn thấp hơn eye 0.1 block)
 *   - velocity: normalized direction * pull * 3.0
 *   - Không có offset 0.5 theo look direction
 *
 * Physics per tick (ArrowEntity.tick):
 *   vel.y -= 0.05 (gravity)
 *   vel   *= 0.99 (drag in air)
 *   pos   += vel
 */
public final class BowTrajectoryUtil {
    private BowTrajectoryUtil() {}

    public static BlockPos predictLanding(ClientPlayerEntity player, int useTimeLeft) {
        World world = player.getWorld();
        float pull = BowItem.getPullProgress(useTimeLeft);
        if (pull < 0.1f) return null;

        float speed = pull * 3.0f;

        // Direction từ yaw/pitch (chuẩn Minecraft)
        float yawRad   = (float) Math.toRadians(player.getYaw());
        float pitchRad = (float) Math.toRadians(player.getPitch());
        double dx = -Math.sin(yawRad) * Math.cos(pitchRad);
        double dy = -Math.sin(pitchRad);
        double dz =  Math.cos(yawRad) * Math.cos(pitchRad);
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len == 0) return null;
        double vx = dx / len * speed;
        double vy = dy / len * speed;
        double vz = dz / len * speed;

        // Spawn: eye position, y - 0.1 (khớp ArrowItem.use)
        Vec3d eye = player.getEyePos();
        double x = eye.x;
        double y = eye.y - 0.1;
        double z = eye.z;

        for (int i = 0; i < 120; i++) {
            // Physics tick: gravity → drag → move
            vy -= 0.05;
            vx *= 0.99;
            vy *= 0.99;
            vz *= 0.99;
            x += vx;
            y += vy;
            z += vz;

            BlockPos cur   = BlockPos.ofFloored(x, y, z);
            BlockPos below = cur.down();

            // Tên chạm vào block solid
            if (!world.getBlockState(cur).isAir()) {
                // Vị trí tick trước (còn ở không khí)
                double prevX = x - vx;
                double prevY = y - vy;
                double prevZ = z - vz;
                BlockPos prev = BlockPos.ofFloored(prevX, prevY, prevZ);
                if (world.getBlockState(prev).isAir()) {
                    return PlacementCalc.findRailPos(world, prev);
                }
                return null;
            }

            // Tên sắp chạm mặt trên của block dưới
            if (!world.getBlockState(below).isAir()
                    && PlacementCalc.isSolidGround(world, below)
                    && world.getBlockState(cur).isAir()) {
                return cur;
            }
        }
        return null;
    }

    public static boolean isHoldingBow(ClientPlayerEntity player) {
        return player.getMainHandStack().getItem() instanceof BowItem ||
               player.getOffHandStack().getItem() instanceof BowItem;
    }
}
